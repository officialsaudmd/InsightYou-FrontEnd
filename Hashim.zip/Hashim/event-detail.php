
<!doctype html>
<html class="no-js" lang="zxx">
<head>
    <meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="description" content="EduRead - Education HTML5 Template">
	<meta name="keywords" content="college, education, institute, responsive, school, teacher, template, university">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>EduRead - Education HTML5 Template</title> 
	<link rel="shortcut icon" href="images/favicon.ico" type="image/x-icon">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/assets/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="css/assets/font-awesome.min.css">
    <!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:600,700%7COpen+Sans:400,600" rel="stylesheet">     
	<!-- Popup -->
	<link href="css/assets/magnific-popup.css" rel="stylesheet"> 
	<!-- Main Menu-->
	<link rel="stylesheet" href="css/assets/meanmenu.css">   
	<!-- Custom CSS -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
</head>
<body class="event-details-1">
<!-- Preloader -->
<div id="preloader">
	<div id="status">&nbsp;</div>
</div>
<header id="header">
	<div class="header-top">
		<div class="container">
			<div class="row">
				<div class="col-sm-6 col-xs-12 header-top-left">
					<ul class="list-unstyled">
						<li><i class="fa fa-phone top-icon"></i> +123 456 789</li>
						<li><i class="fa fa-envelope top-icon"></i> hello@eduread.com</li>
					</ul>
				</div>
				<div class="col-sm-6 col-xs-12 header-top-right">
					<ul class="list-unstyled">
						<li><a href="register.html"><i class="fa fa-user-plus top-icon"></i> Sing up</a></li>
						<li><a href="login.html"><i class="fa fa-lock top-icon"></i>Login</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div><!-- Ends: .header-top -->

	<div class="header-body">
		<nav class="navbar edu-navbar">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="#" class="navbar-brand  data-scroll"><img src="images/logo.png" alt=""><span>EduRead</span></a>
				</div>

				<div class="collapse navbar-collapse edu-nav main-menu menu-icon" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav pull-right">
						<li class="active" ><a data-scroll="" href="index.html">Home</a>
							<!-- dropdwon start -->
                            <ul class="dropdown list-unstyled">
                                <li><a href="index.html">Home Version One</a></li>
                                <li><a href="index-02.html">Home Version Two</a></li>
                                <li><a href="index-03.html">Home Version Three</a></li>
                                <li><a href="index-04.html">Home Version Four</a></li>
                            </ul>
                            <!-- dropdown end -->
						</li>
						<li><a data-scroll="" href="courses-01.html">Courses</a>
							<!-- dropdwon start -->
                            <ul class="dropdown list-unstyled">
                                <li><a href="courses-01.html">Course Style One</a></li>
                                <li><a href="courses-02.html">Course Style Two</a></li>
                                <li><a href="courses-03.html">Course Style Three</a></li>
                                <li class="dropdown-list-box-02"><a href="#">Dropdown<i class="fa fa-angle-right menu-icon"></i></a>
	                                <ul class="dropdown-list_2 list-unstyled">
	                                    <li><a href="#">Label One</a></li>
	                                    <li><a href="#">Label One</a></li>
	                                    <li><a href="#">Label One</a></li>
	                                    <li class="dropdown-list-box-03"><a href="#">Label One<i class="fa fa-angle-right menu-icon"></i></a>
			                                <ul class="dropdown-list_3 list-unstyled">
			                                    <li><a href="#">Label Two</a></li>
			                                    <li><a href="#">Label Two</a></li>
			                                </ul>
	                                    </li>
	                                </ul>									
                                </li>
                                <li><a href="courses-carousel.html">Course Carousel Style</a></li>
                                <li><a href="course-details.html">Course Details</a></li>
                                <li><a href="course-details-left-sidebar.html">Course Details Sidebar</a></li>
                            </ul>
                            <!-- dropdown end -->
						</li>
						<li><a data-scroll href="event-list.html">Event</a>
							<!-- dropdwon start -->
                            <ul class="dropdown list-unstyled">
                                <li><a href="event-list.html">Event List One</a></li>
                                <li><a href="event-list-1.html">Event List Two</a></li>
                                <li><a href="event-grid-2.html">Event Two Grid</a></li>
                                <li><a href="event-grid-3.html">Event Three Grid</a></li>
								<li><a href="event-details.html">Event Details</a></li>
                            </ul>
                            <!-- dropdown end -->
						</li>
						<li><a data-scroll href="#">Pages</a>
							<ul class="list-unstyled dropdown">
                                <li><a href="courses-01.html">Courses</a></li>
                                <li><a href="event-list.html">Events</a></li>
                                <li><a href="teachers-01.html">Teachers</a></li>
                                <li class="dropdown-list-box-02"><a href="#">Dropdown<i class="fa fa-angle-right menu-icon"></i></a>
	                                <ul class="dropdown-list_2 list-unstyled">
	                                    <li><a href="#">Label One</a></li>
	                                    <li><a href="#">Label One</a></li>
	                                    <li><a href="#">Label One</a></li>
	                                    <li class="dropdown-list-box-03"><a href="#">Label One<i class="fa fa-angle-right menu-icon"></i></a>
			                                <ul class="dropdown-list_3 list-unstyled">
			                                    <li><a href="#">Label Two</a></li>
			                                    <li><a href="#">Label Two</a></li>
			                                </ul>
	                                    </li>
	                                </ul>									
                                </li>
                                <li><a href="teachers-profile.html">Teachers Porfile</a></li>
                                <li><a href="become-a-teacher.html">Become a Teacher</a></li>
                                <li><a href="login.html">Login</a></li>
                                <li><a href="register.html">Registation</a></li>
                                <li><a href="blog.html">Blog</a></li>
                                <li><a href="blog-post.html">Post</a></li>
                                <li><a href="contact.html">Contact</a></li>
							</ul>
						</li>
						<li><a data-scroll href="teachers-01.html">Teachers</a>
							<!-- dropdwon start -->
                            <ul class="dropdown list-unstyled">
                                <li><a href="teachers-01.html">Teachers Style One</a></li>
                                <li><a href="teachers-02.html">Teachers Style Two</a></li>
                                <li><a href="teachers-profile.html">Teachers Porfile</a></li>
                                <li><a href="become-a-teacher.html">Become a Teacher</a></li>
                            </ul>
                            <!-- dropdown end -->
						</li>
						<li><a data-scroll href="blog.html">Blog</a>
							<!-- dropdwon start -->
                            <ul class="dropdown list-unstyled">
                                <li><a href="blog.html">Blog</a></li>
                                <li><a href="blog-post.html">Blog Post</a></li>
                            </ul>
                            <!-- dropdown end -->
						</li>
						<li><a data-scroll href="contact.html">Contact</a></li>
						<li><a data-scroll href="#"><i class="fa fa-search search_btn"></i></a>
							<div id="search">
							  	<button type="button" class="close">×</button>
							 	 <form>
							   		 <input type="search" value="" placeholder="Search here...."  required/>
							   		 <button type="submit" class="btn btn_common blue">Search</button>
							 	 </form>
							</div>
						</li>
					</ul>
				</div><!-- /.navbar-collapse -->
			</div><!-- /.container -->
		</nav>
		
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="intro-text ">
						<h1>Event Details</h1>
						<p><span><a href="">Home <i class='fa fa-angle-right'></i></a></span> <span><a href=""> Event <i class='fa fa-angle-right'></i></a></span> <span class="b-active">Event Details</span></p>
					</div>
				</div>
			</div><!-- /.row -->
		</div><!-- /.container -->
	</div>
</header>
	<!--  End header section-->


<div class="event-details">
	<div class="container">
		<div class="row">
			<div class="col-sm-8 post_left-side">
				<div class="row">
					<div class="col-sm-12 ">
						<div class="post-img-box">
							<img src="images/event/event-details.jpg" alt="" class="img-responsive">
						</div>
						<div class="clock-countdown">
							<div class="site-config"></div>
							<div class="coundown-timer">
								<div class="single-counter"><span class="days">21</span><span class="normal">Days</span></div>
								<div class="single-counter single-chag-color"><span class="hours">12</span><span class="normal">Hours</span></div>
								<div class="single-counter"><span class="minutes">25</span><span class="normal">Minutes</span></div>
								<div class="single-counter single-chag-color"><span class="seconds">48</span><span class="normal">Seconds</span></div>
							</div>
						</div>
					</div>
					<div class="col-sm-12">
						<div class="description-content">
							<div class="description-heading">
								<h3><a href="">Seven UK business schools for intelligent students</a></h3>
								<p>
									<span><i class="fa fa-calendar"></i>22 December, 2016</span>
									<span><i class="fa fa-map-marker"></i>NewYork Tower, Melbourne</span>
								</p>
							</div>
							<div class="description-text">
								<div class="row">
									<div class="col-sm-1">
										<div class="description-side-left">
											<ul class="pst-social-icon list-unstyled">
											  	<li><a href="" class="fa fa-facebook facebook"></a></li>
											  	<li><a href="" class="fa fa-google-plus google"></a></li>
											 	<li><a href="" class="fa fa-twitter twitter"></a></li>
											 	<li><a href="" class="fa fa-linkedin linkedin"></a></li>
											 	<li><a href="" class="fa fa-instagram instagram"></a></li>
											 	<li><a href="" class="fa fa-youtube youtube"></a></li>
											 	<li><a href="" class="fa fa-pinterest-p pinterest"></a></li>
											 </ul>
										</div>
									</div>
									<div class="col-sm-11">
										<div class="description-text-right">
											<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in finibus neque. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Vestibulum interdum diam non mi cursus venenatis. Morbi lacinia libero et elementum vulputate. Vivamus et facilisis mauris. Maecenas nec massa auctor, ultricies massa eu, tristique erat. Vivamus in ipsum quis elit vehicula tempus vitae quis lacus. Eu pellentesque, accumsan tellus leo, ultrices mi dui lectus sem nulla eu.Eu pellentesque, accumsan tellus leo, ultrices mi dui 
											</p>
											<p>lectus sem nulla eu. Maecenas arcu, nec ridiculus quisque orci, vulputate mattis risus erat.
											lectus sem nulla eu.Eu pellentesque, accumsan tellus leo, ultrices mi dui lectus sem nulla eu. Maecenas arcu, nec ridiculus quisque orci, vulputate mattis risus erat.</p>
											<p class="description-speech">
											<i class="fa fa-quote-right"></i>
											Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae id efficitur condimentum, dui nisl ullamcorper diam, at molestie nulla erat gna egestas tempor Lorem ipsum dolor sit. 
											</p>
											<p>lectus sem nulla eu. Maecenas arcu, nec ridiculus quisque orci, vulputate mattis risus erat.
											lectus sem nulla eu.Eu pellentesque, accumsan tellus leo, ultrices mi dui lectus sem nulla eu. Maecenas arcu, nec ridiculus quisque orci, vulputate mattis risus erat.</p>
										</div>
									</div>
								</div>								
							</div>
						</div>
					</div>

					<div class="col-sm-12 col-md-12">
						<div class="more-events">
							<div class="row">
								<h3>Upcoming Events</h3>
								<div class="col-sm-6 col-md-4 event-single">
									<div class="event-single-box">
										<div class="img-box">
											<img src="images/event/up-event-01.jpg" alt="" class="img-responsive">
										</div>
										<div class="blog-content">
											<h4><a href="#">The future of Web Design</a></h4>
											<p class="blog-time">
												<span>
													<i class="fa fa-calendar event-icon"></i>
													12 July, 2018
												</span>
												<span>
													<i class="fa fa-comment"></i>
													12										
												</span>
											</p>
											<div class="content-bottom">
												<p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum.</p>
												<span class="first-item"><a href="#">Read More<i class="fa fa-long-arrow-right blog-btn-icon"></i></a></span>
											</div>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-md-4 event-single">
									<div class="event-single-box">
										<div class="img-box">
											<img src="images/event/up-event-02.jpg" alt="" class="img-responsive">
										</div>
										<div class="blog-content">
											<h4><a href="#">The future of php Programing</a></h4>
											<p class="blog-time">
												<span>
													<i class="fa fa-calendar event-icon"></i>
													19 July, 2018
												</span>
												<span>
													<i class="fa fa-comment"></i>
													17										
												</span>
											</p>
											<div class="content-bottom">
												<p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum.</p>
												<span class="first-item"><a href="#">Read More<i class="fa fa-long-arrow-right blog-btn-icon"></i></a></span>
											</div>
										</div>
									</div>
								</div>

								<div class="col-sm-6 col-md-4 event-single">
									<div class="event-single-box">
										<div class="img-box">
											<img src="images/event/up-event-03.jpg" alt="" class="img-responsive">
										</div>
										<div class="blog-content">
											<h4><a href="#">The future of Web Design</a></h4>
											<p class="blog-time">
												<span>
													<i class="fa fa-calendar event-icon"></i>
													12 July, 2018
												</span>
												<span>
													<i class="fa fa-comment"></i>
													18										
												</span>
											</p>
											<div class="content-bottom">
												<p>Lorem ipsum dolor sit amet consepctetur adipiscing elit Etiam at ipsum.</p>
												<span class="first-item"><a href="#">Read More<i class="fa fa-long-arrow-right blog-btn-icon"></i></a></span>	
											</div>
										</div>
									</div>
								</div>
							</div>	
						</div>		
					</div><!--End .row-->

					<div class="col-sm-12">
						<div class="leave-comment-box">
	                        <div class="comment-respond">
	                            <div class="comment-reply-title">
	                                <h3>Join Event</h3>
	                            </div>
	                            <div class="comment-form">
	                                <form>
		                                <div class="row">
		                               		<div class="col-sm-12">
			                                	<div class="form-group">
			                                        <textarea class="form-control" rows="8" placeholder="Type Your Comments"></textarea>
			                                    </div>
		                                    </div>
		                                    <div class="col-sm-4">
			                                    <div class="form-group">
			                                        <input type="text" class="form-control" placeholder="Your Name">
			                                    </div>
		                                    </div>
		                                    <div class="col-sm-4">
			                                    <div class="form-group">
			                                        <input type="email" class="form-control" placeholder="Your E-mail">
			                                    </div>
		                                    </div>
		                                    <div class="col-sm-4">
			                                    <div class="form-group">
			                                        <input type="text" class="form-control" placeholder="Website URL">
			                                    </div>
		                                    </div>		
		                                    <div class="col-sm-12">                                    
			                                    <div class="full-width">
			                                        <input value="Join Now"  type="submit">
			                                    </div>
		                                    </div>	
	                                    </div>
	                                </form>
	                            </div>
	                        </div>
						</div>
					</div>
				</div>	
			</div>


			<div class="col-sm-4">
				<div class="sidebar-text-post">							
					<div class="row">
						<div class="col-sm-12">
							<h3>Next Events</h3>
							<div class="categories-item-post">
								<ul class="list-unstyled">
									<li><a href="#"><i class="fa fa-angle-right"></i>USA <span>(23)</span></a></li>
									<li><a href="#"><i class="fa fa-angle-right"></i>Norway<span>(23)</span></a></li>
									<li><a href="#"><i class="fa fa-angle-right"></i>Russia<span>(23)</span></a></li>
									<li><a href="#"><i class="fa fa-angle-right"></i>London<span>(23)</span></a></li>
									<li><a href="#"><i class="fa fa-angle-right"></i>Australia <span>(23)</span></a></li>
									<li><a href="#"><i class="fa fa-angle-right"></i>Singapur <span>(23)</span></a></li>
								</ul>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="col-sm-12 blog-padding-none">
							<h3>Event tags</h3>
							<div class="populer-tags">		
								<div class="tagcloud">
									<a href="#">USA</a>
									<a href="#">Russia</a>
									<a href="#">Events</a>
									<a href="#">Learning</a>
									<a href="#">Norway</a>
									<a href="#">Australia</a>
									<a href="#">Speakers</a>
									<a href="#">Audio</a>
									<a href="#">Singapur</a>
								</div>
							</div>
						</div>	
					</div>		
				</div>						
			</div>
		</div>
	</div>	
</div>




<!-- Footer Area section -->
<footer>
	<div class="container">
		<div class="row">
			<div class=" col-sm-12 footer-content-box">
				<div class="col-sm-3">
					<h3><span><i class="fa fa-graduation-cap footer-h-icon"></i></span> EduRead</h3>
					<p>We are Educatios, creat your passion and inspiration. And hope success will come for your dream. Please send email and get latest news.</p>
					<ul class="list-unstyled">
						<li><span><i class="fa fa-phone footer-icon"></i></span>0123-456-789</li>
						<li><span><i class="fa fa-envelope footer-icon"></i></span>hello@education.com</li>
						<li><span><i class="fa fa-map-marker footer-icon"></i></span>01 Central Park, NYC</li>
					</ul>
				</div>

				<div class="col-sm-2">
					<h3>Courses</h3>
					<ul class="list-unstyled">
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Web Design</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Apps Developer</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Graphic Design</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>PHP Tranning</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>IOS Developer</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>App Design</a></li>
					</ul>
				</div>

				<div class="col-sm-2">
					<h3>Links</h3>
					<ul class="list-unstyled">
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>About Us</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Teacher</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Blog</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Events</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Gallery</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Contact</a></li>
					</ul>
				</div>

				<div class="col-sm-2">
					<h3>Support</h3>
					<ul class="list-unstyled">
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Documentation</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Forums</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Language Packs</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Release Status</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Documentation</a></li>
						<li><a href="#"><span><i class="fa fa-long-arrow-right footer-icon"></i></span>Forums</a></li>
					</ul>
				</div>	

				<div class="col-sm-3">
					<h3>Get in touch</h3>
					<p>Enter your email and we'll send you more information.</p>

					<form action="#">
						<div class="form-group">
							<input placeholder="Your Email" type="email" required="" >
							<div class="submit-btn">
								<button type="submit" class="text-center">Subscribe</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="footer-bottom">
		<div class="container">
			<div class="footer-bottom-inner">
				<div class="row">
					<div class="col-md-6 col-sm-12 footer-no-padding">
						<p>&copy; Copyright 2018 EcologyTheme | All rights reserved</p>
					</div>
					<div class="col-md-6 col-sm-12 footer-no-padding">
						<ul class="list-unstyled footer-menu text-right">
							<li>Follow us:</li>
							<li><a href=""><i class="fa fa-facebook facebook"></i></a></li>
							<li><a href=""><i class="fa fa-twitter twitter"></i></a></li>
							<li><a href=""><i class="fa fa-instagram instagram"></i></a></li>
							<li><a href=""><i class="fa fa-google-plus google"></i></a></li>
							<li><a href=""><i class="fa fa-skype skype"></i></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div><!-- ./ End footer-bottom -->		
</footer><!-- ./ End Footer Area -->

    <!-- ============================
    JavaScript Files
    ============================= -->
    <!-- jQuery -->
	<script src="js/vendor/jquery-1.12.4.min.js"></script>
	<!-- Bootstrap JS -->
	<script src="js/assets/bootstrap.min.js"></script>
	<!-- Sticky JS -->
	<script src="js/assets/jquery.sticky.js"></script>
	<!-- Popup -->
    <script src="js/assets/jquery.magnific-popup.min.js"></script>
	<!-- Counter Up -->
    <script src="js/assets/jquery.counterup.min.js"></script>
    <script src="js/assets/waypoints.min.js"></script>
 	<!-- owl carousel -->
    <script src="js/assets/owl.carousel.min.js"></script>
   <!-- Slick Slider-->
    <script src="js/assets/slick.min.js"></script>
    <!-- Main Menu -->
	<script src="js/assets/jquery.meanmenu.min.js"></script>
	<!-- Custom JS -->
	<script src="js/custom.js"></script>
</body>
</html>
